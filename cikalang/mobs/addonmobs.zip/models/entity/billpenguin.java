// Made with Blockbench 3.7.4
// Exported for Minecraft version 1.15
// Paste this class into your mod and generate all required imports


public class billpenguin extends EntityModel<Entity> {
	private final ModelRenderer body;
	private final ModelRenderer block1;
	private final ModelRenderer leftLeg;
	private final ModelRenderer rightLeg;
	private final ModelRenderer walking;
	private final ModelRenderer bone4;
	private final ModelRenderer block2;
	private final ModelRenderer rightArm;
	private final ModelRenderer leftArm;
	private final ModelRenderer head;
	private final ModelRenderer eye;
	private final ModelRenderer eye2;
	private final ModelRenderer hat;
	private final ModelRenderer beak;
	private final ModelRenderer mouth;

	public billpenguin() {
		textureWidth = 64;
		textureHeight = 64;

		body = new ModelRenderer(this);
		body.setRotationPoint(0.0F, 14.0F, 1.0F);
		

		block1 = new ModelRenderer(this);
		block1.setRotationPoint(0.0F, 10.0F, 0.0F);
		body.addChild(block1);
		

		leftLeg = new ModelRenderer(this);
		leftLeg.setRotationPoint(3.0F, -1.0F, -3.0F);
		block1.addChild(leftLeg);
		leftLeg.setTextureOffset(8, 41).addBox(-1.0F, 0.0F, -3.0F, 2.0F, 1.0F, 4.0F, 0.0F, false);

		rightLeg = new ModelRenderer(this);
		rightLeg.setRotationPoint(-3.0F, -1.0F, -3.0F);
		block1.addChild(rightLeg);
		rightLeg.setTextureOffset(8, 36).addBox(-1.0F, 0.0F, -3.0F, 2.0F, 1.0F, 4.0F, 0.0F, false);

		walking = new ModelRenderer(this);
		walking.setRotationPoint(0.0F, -1.0F, -0.5F);
		block1.addChild(walking);
		

		bone4 = new ModelRenderer(this);
		bone4.setRotationPoint(0.0F, -8.0F, 0.5F);
		walking.addChild(bone4);
		bone4.setTextureOffset(0, 0).addBox(-4.0F, -5.0F, -4.0F, 8.0F, 13.0F, 7.0F, 0.0F, false);

		block2 = new ModelRenderer(this);
		block2.setRotationPoint(0.0F, -18.1F, 2.3F);
		walking.addChild(block2);
		

		rightArm = new ModelRenderer(this);
		rightArm.setRotationPoint(4.0F, 5.1F, -2.3F);
		block2.addChild(rightArm);
		setRotationAngle(rightArm, 0.0F, 0.0F, -0.0873F);
		rightArm.setTextureOffset(0, 36).addBox(0.0F, 0.0F, -1.5F, 1.0F, 9.0F, 3.0F, 0.0F, false);

		leftArm = new ModelRenderer(this);
		leftArm.setRotationPoint(-4.0F, 5.1F, -2.3F);
		block2.addChild(leftArm);
		setRotationAngle(leftArm, 0.0F, 0.0F, 0.0873F);
		leftArm.setTextureOffset(32, 20).addBox(-1.0F, 0.0F, -1.5F, 1.0F, 9.0F, 3.0F, 0.0F, false);

		head = new ModelRenderer(this);
		head.setRotationPoint(0.0F, 2.1F, -2.3F);
		block2.addChild(head);
		head.setTextureOffset(0, 20).addBox(-4.0F, -4.0F, -4.0F, 8.0F, 8.0F, 8.0F, -1.0F, false);

		eye = new ModelRenderer(this);
		eye.setRotationPoint(0.0F, 17.0F, 0.0F);
		head.addChild(eye);
		eye.setTextureOffset(18, 48).addBox(2.01F, -18.5F, -2.25F, 0.0F, 3.0F, 3.0F, 0.0F, false);

		eye2 = new ModelRenderer(this);
		eye2.setRotationPoint(-6.0F, 17.0F, 0.0F);
		head.addChild(eye2);
		eye2.setTextureOffset(10, 48).addBox(3.99F, -18.5F, -2.25F, 0.0F, 3.0F, 3.0F, 0.0F, false);

		hat = new ModelRenderer(this);
		hat.setRotationPoint(0.0F, 17.0F, 0.0F);
		head.addChild(hat);
		

		beak = new ModelRenderer(this);
		beak.setRotationPoint(0.0F, 1.0F, -3.0F);
		head.addChild(beak);
		beak.setTextureOffset(0, 48).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 3.0F, 0.0F, false);
		beak.setTextureOffset(0, 48).addBox(-1.0F, -1.0F, 0.0F, 2.0F, 1.0F, 3.0F, 0.0F, false);

		mouth = new ModelRenderer(this);
		mouth.setRotationPoint(0.0F, 0.0F, 0.0F);
		beak.addChild(mouth);
		mouth.setTextureOffset(26, 48).addBox(-1.0F, 0.0F, -2.0F, 2.0F, 1.0F, 2.0F, 0.0F, false);
		mouth.setTextureOffset(26, 48).addBox(-1.0F, 0.0F, 0.0F, 2.0F, 1.0F, 2.0F, 0.0F, false);
	}

	@Override
	public void setRotationAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch){
		//previously the render function, render code was moved to a method below
	}

	@Override
	public void render(MatrixStack matrixStack, IVertexBuilder buffer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha){
		body.render(matrixStack, buffer, packedLight, packedOverlay);
	}

	public void setRotationAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}
}